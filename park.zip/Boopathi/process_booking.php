<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION['user_name'] = $_POST['user_name'] ?? '';
    $_SESSION['phone'] = $_POST['phone'] ?? '';
    $_SESSION['aadhaar'] = $_POST['aadhaar'] ?? '';
    $_SESSION['car_number'] = $_POST['car_number'] ?? '';
    $_SESSION['license_number'] = $_POST['license_number'] ?? '';
    $_SESSION['days'] = $_POST['days'] ?? '';
    $_SESSION['amount'] = $_POST['amount'] ?? '';
    $_SESSION['date_time'] = date("Y-m-d H:i:s");

    header("Location: payment.php");
    exit();
} else {
    echo "Invalid request!";
}
?>
