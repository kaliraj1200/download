<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $utr = $_POST['utr'] ?? '';

    if (!empty($utr)) {
        $_SESSION['utr'] = $utr;

        echo "<script>
                alert('Payment verified successfully!');
                window.location.href = 'invoice.php';
              </script>";
        exit();
    } else {
        echo "<script>alert('Invalid UTR! Please enter a valid transaction ID.'); window.history.back();</script>";
        exit();
    }
} else {
    echo "Invalid request!";
}
?>
