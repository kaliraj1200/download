---------------------------RE-work-----------
CREATE DATABASE IF NOT EXISTS parking_system;
--------------------------------------------------------------
CREATE TABLE parking_slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slot_number VARCHAR(50) UNIQUE NOT NULL,
    location VARCHAR(255) NOT NULL,
    status ENUM('available', 'occupied') DEFAULT 'available'
);

ALTER TABLE parking_slots ADD COLUMN location_name VARCHAR(255) NULL;

----------------------------------------------------------

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    car_number VARCHAR(20) NOT NULL,
    license_number VARCHAR(50) NOT NULL,
    aadhaar_number VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-----------------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);
ALTER TABLE users ADD COLUMN phone VARCHAR(20) NOT NULL;
ALTER TABLE users ADD COLUMN car_number VARCHAR(20) NOT NULL;
ALTER TABLE users ADD COLUMN license_number VARCHAR(50) NOT NULL;
ALTER TABLE users ADD COLUMN aadhaar_number VARCHAR(12) NOT NULL;
ALTER TABLE users ADD COLUMN phone VARCHAR(15), ADD COLUMN car_number VARCHAR(20);


------------------------------------------------------------------------------------------
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    slot_id INT NOT NULL,
    days INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_status ENUM('pending', 'paid') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (slot_id) REFERENCES parking_slots(id)
);
ALTER TABLE bookings ADD COLUMN utr_number VARCHAR(50) NULL;

------------------------------------------------------
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    phone VARCHAR(20),
    car_number VARCHAR(50),
    slot VARCHAR(50),
    days INT,
    amount DECIMAL(10,2),
    date_time DATETIME,
    utr VARCHAR(50)
);
