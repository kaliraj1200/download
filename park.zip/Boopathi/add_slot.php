<?php
session_start();
include 'config.php';

// Check admin login
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $slot_number = $conn->real_escape_string($_POST['slot_number']);
    $location = $conn->real_escape_string($_POST['location']);

    // Check if slot already exists
    $check = $conn->query("SELECT id FROM parking_slots WHERE slot_number = '$slot_number'");
    if ($check->num_rows > 0) {
        $error = "Slot number already exists!";
    } else {
        $conn->query("INSERT INTO parking_slots (slot_number, location, status) VALUES ('$slot_number', '$location', 'available')");
        header("Location: admin_home.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Parking Slot</title>
    <link rel="stylesheet" href="Css/adminhome.css">
    <style>
        .form-container { max-width: 400px; margin: 50px auto; }
        .form-container input, textarea { width: 100%; margin-bottom: 10px; padding: 8px; }
        .btn { background: green; color: white; padding: 10px; text-decoration: none; display: inline-block; border: none; cursor: pointer; }
        .error { color: red; margin-bottom: 10px; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Add New Parking Slot</h2>
    <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>
    <form method="POST">
        <label>Slot Number:</label>
        <input type="text" name="slot_number" required placeholder="Eg: P1, A2, etc">
        
        <label>Location / Description:</label>
        <textarea name="location" rows="3" required placeholder="Eg: Basement Level 1, Near Exit Gate"></textarea>
        
        <button type="submit" class="btn">Add Slot</button>
    </form>
    <br>
    <a href="admin_home.php" class="btn" style="background: gray;">Back to Dashboard</a>
</div>

</body>
</html>
