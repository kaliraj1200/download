<?php
session_start();

// Ensure required session data is available
if (!isset($_SESSION['user_name'], $_SESSION['phone'], $_SESSION['car_number'], $_SESSION['slot'], $_SESSION['days'], $_SESSION['amount'], $_SESSION['date_time'], $_SESSION['utr'])) {
    die("Error: Missing session data. Please complete the payment process first.");
}

// Include FPDF library (Make sure the path is correct)
require('fpdf/fpdf.php'); 

// Create PDF instance
$pdf = new FPDF();
$pdf->AddPage();

// Set Title
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(190, 10, "Smart Parking - Payment Invoice", 1, 1, 'C');
$pdf->Ln(10);

// User details
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(100, 10, "Name: " . $_SESSION['user_name'], 0, 1);
$pdf->Cell(100, 10, "Phone: " . $_SESSION['phone'], 0, 1);
$pdf->Cell(100, 10, "Car Number: " . $_SESSION['car_number'], 0, 1);
$pdf->Cell(100, 10, "Parking Slot: " . $_SESSION['slot'], 0, 1);
$pdf->Cell(100, 10, "Days: " . $_SESSION['days'], 0, 1);
$pdf->Cell(100, 10, "Amount: ₹" . $_SESSION['amount'], 0, 1);
$pdf->Cell(100, 10, "Date & Time: " . $_SESSION['date_time'], 0, 1);
$pdf->Cell(100, 10, "Transaction ID (UTR): " . $_SESSION['utr'], 0, 1);
$pdf->Ln(10);

// Thank You Note
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(190, 10, "Thank you for using Smart Parking!", 1, 1, 'C');

// Output PDF for download
$pdf->Output("D", "Parking_Invoice.pdf");
?>
