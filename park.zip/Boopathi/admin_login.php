<?php
session_start();

// Hardcoded credentials
$admin_username = "admin";
$admin_password = "1234";

// If form submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === $admin_username && $password === $admin_password) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin_home.php"); // Redirect to admin_home.php
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}

// If already logged in, redirect directly to admin_home.php
if (isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_home.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <style>
        body { font-family: Arial; text-align: center; margin-top: 100px; }
        input { padding: 10px; margin: 10px; }
        button { padding: 10px 20px; background: #007bff; color: white; border: none; }
        .error { color: red; }
    </style>
</head>
<body>
    <h2>Admin Login</h2>
    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <button type="submit">Login</button>
    </form>
</body>
</html>
