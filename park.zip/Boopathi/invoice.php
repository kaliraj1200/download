<?php
session_start();

if (!isset($_SESSION['user_name']) || !isset($_SESSION['utr'])) {
    header("Location: booking.php");
    exit();
}

// Retrieve session values
$user_name = $_SESSION['user_name'];
$phone = $_SESSION['phone'];
$aadhaar = $_SESSION['aadhaar'];
$car_number = $_SESSION['car_number'];
$license_number = $_SESSION['license_number'];
$days = $_SESSION['days'];
$amount = $_SESSION['amount'];
$date_time = $_SESSION['date_time'];
$utr = $_SESSION['utr'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Invoice</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script>
        window.onload = function() {
            const { jsPDF } = window.jspdf;
            let doc = new jsPDF();

            doc.setFont("helvetica");
            doc.setFontSize(16);
            doc.text("Parking Booking Invoice", 20, 20);

            doc.setFontSize(12);
            doc.text("Name: <?php echo $user_name; ?>", 20, 40);
            doc.text("Phone: <?php echo $phone; ?>", 20, 50);
            doc.text("Aadhaar: <?php echo $aadhaar; ?>", 20, 60);
            doc.text("Car Number: <?php echo $car_number; ?>", 20, 70);
            doc.text("License Number: <?php echo $license_number; ?>", 20, 80);
            doc.text("Days: <?php echo $days; ?>", 20, 90);
            doc.text("Total Amount: ₹<?php echo $amount; ?>", 20, 100);
            doc.text("Payment UTR: <?php echo $utr; ?>", 20, 110);
            doc.text("Booking Date: <?php echo $date_time; ?>", 20, 120);

            doc.save("Parking_Invoice.pdf");
            setTimeout(() => { window.location.href = "index.php"; }, 2000);
        };
    </script>
</head>
<body>
    <div style="text-align:center; margin-top:50px;">
        <h2>Your invoice is being downloaded...</h2>
    </div>
</body>
</html>
