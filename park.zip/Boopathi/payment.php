<?php
session_start();
$pageTitle = "Payment - Parking Booking";

if (!isset($_SESSION['user_name'])) {
    header("Location: booking.php");
    exit();
}

// Retrieve session values
$user_name = $_SESSION['user_name'];
$phone = $_SESSION['phone'];
$aadhaar = $_SESSION['aadhaar'];
$car_number = $_SESSION['car_number'];
$license_number = $_SESSION['license_number'];
$days = $_SESSION['days'];
$amount = $_SESSION['amount'];
$date_time = $_SESSION['date_time'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Complete Your Payment</h2>
        <form action="verify_payment.php" method="post">
            <label>Name:</label>
            <input type="text" value="<?php echo htmlspecialchars($user_name); ?>" readonly>

            <label>Phone Number:</label>
            <input type="text" value="<?php echo htmlspecialchars($phone); ?>" readonly>

            <label>Aadhaar Number:</label>
            <input type="text" value="<?php echo htmlspecialchars($aadhaar); ?>" readonly>

            <label>Car Number:</label>
            <input type="text" value="<?php echo htmlspecialchars($car_number); ?>" readonly>

            <label>License Number:</label>
            <input type="text" value="<?php echo htmlspecialchars($license_number); ?>" readonly>

            <label>Number of Days:</label>
            <input type="text" value="<?php echo htmlspecialchars($days); ?>" readonly>

            <label>Amount to Pay (₹):</label>
            <input type="text" value="<?php echo htmlspecialchars($amount); ?>" readonly>

            <div class="upi-section">
                <h3>Scan & Pay via UPI</h3>
                <img src="images/upi_qr.png" alt="UPI QR Code">
                <p>Or Pay to UPI ID: <b>smartparking@upi</b></p>
            </div>

            <label>Enter UTR (Transaction ID):</label>
            <input type="text" name="utr" required>

            <button type="submit" class="btn">Verify Payment</button>
        </form>
    </div>
</body>
</html>
