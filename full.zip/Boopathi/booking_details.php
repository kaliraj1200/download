<?php
session_start();
$pageTitle = "Parking Booking";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="styles.css">
    <script>
        function calculateTotal() {
            let days = document.getElementById("days").value;
            let perDayCharge = 200;
            let totalAmount = days * perDayCharge;
            document.getElementById("amount").value = totalAmount;
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Book Your Parking Slot</h2>
        <form action="process_booking.php" method="post">
            <label>Name:</label>
            <input type="text" name="user_name" required>

            <label>Phone Number:</label>
            <input type="text" name="phone" required>

            <label>Aadhaar Number:</label>
            <input type="text" name="aadhaar" required>

            <label>Car Number:</label>
            <input type="text" name="car_number" required>

            <label>License Number:</label>
            <input type="text" name="license_number" required>

            <label>Number of Days:</label>
            <input type="number" id="days" name="days" min="1" required oninput="calculateTotal()">

            <label>Total Amount (₹):</label>
            <input type="text" id="amount" name="amount" readonly>

            <button type="submit" class="btn">Proceed to Pay</button>
        </form>
    </div>
</body>
</html>
