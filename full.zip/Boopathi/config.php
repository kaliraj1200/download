<?php
$host = "127.0.0.1";  // Use "127.0.0.1" instead of "localhost"
$user = "root";       // Default XAMPP MySQL username
$pass = "";           // Default XAMPP password (leave empty)
$dbname = "parking_system";  // Your database name

$conn = new mysqli($host, $user, $pass, $dbname, 3306); // Specify MySQL port 3306

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
