<?php
session_start();
include 'db_connect.php';

if (!isset($_GET['booking_id'])) {
    die("Missing booking ID.");
}

$booking_id = intval($_GET['booking_id']);

// Fetch booking, user, slot info
$stmt = $conn->prepare("SELECT 
    b.*, u.name, u.phone, u.car_number, s.slot_number, s.location_name
    FROM bookings b 
    JOIN users u ON b.user_id = u.id 
    JOIN parking_slots s ON b.slot_id = s.id 
    WHERE b.id = ? LIMIT 1");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    die("Booking not found.");
}
$data = $result->fetch_assoc();
$date_time = date("d-m-Y H:i:s");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Payment Successful</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <style>
        body {
            text-align: center;
            font-family: Arial, sans-serif;
            margin-top: 50px;
        }
        button {
            margin-top: 20px;
            padding: 10px 20px;
            background: green;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: darkgreen;
        }
        .home-btn {
            background: #007bff;
            margin-top: 10px;
        }
        .home-btn:hover {
            background: #0056b3;
        }
    </style>
</head>

<body>
    <h2>✅ Payment Successful!</h2>
    <p>Your bill will download shortly...</p>

    <button id="downloadBtn">Download Bill Manually</button><br>
    <button class="home-btn" onclick="window.location.href='home.php';">Go Back Home</button>

    <script>
    document.addEventListener("DOMContentLoaded", function () {
        const waitForJsPDF = setInterval(() => {
            if (window.jspdf && window.jspdf.jsPDF) {
                clearInterval(waitForJsPDF);

                const { jsPDF } = window.jspdf;

                function generatePDF() {
                    const doc = new jsPDF();

                    doc.setFontSize(18);
                    doc.text("Parking Booking Invoice", 70, 20);
                    doc.setFontSize(12);
                    doc.text("Date & Time: <?php echo $date_time; ?>", 14, 30);

                    doc.text("Name: <?php echo htmlspecialchars($data['name']); ?>", 14, 40);
                    doc.text("Phone: <?php echo htmlspecialchars($data['phone']); ?>", 14, 50);
                    doc.text("Car Number: <?php echo htmlspecialchars($data['car_number']); ?>", 14, 60);
                    doc.text("Location: <?php echo htmlspecialchars($data['location_name']); ?>", 14, 70);
                    doc.text("Slot Number: <?php echo htmlspecialchars($data['slot_number']); ?>", 14, 80);
                    doc.text("Booked Days: <?php echo htmlspecialchars($data['days']); ?>", 14, 90);
                    doc.text("Total Amount Paid: ₹<?php echo htmlspecialchars($data['amount']); ?>", 14, 100);
                    doc.text("UTR Number: <?php echo htmlspecialchars($data['utr_number']); ?>", 14, 110);

                    doc.setFontSize(10);
                    doc.text("Thank you for booking with us!", 14, 130);

                    doc.save("Parking_Bill_<?php echo $booking_id; ?>.pdf");

                    alert("✅ Bill Downloaded Successfully!");
                }

                // Auto download after delay
                setTimeout(() => {
                    generatePDF();
                }, 1000);

                // Manual button click fallback
                document.getElementById("downloadBtn").addEventListener("click", function () {
                    generatePDF();
                });
            }
        }, 200);
    });
    </script>
    
</body>

</html>
