<?php
    $pageTitle = "Smart Parking";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        body {
            background-color: #f4f4f4;
            color: #333;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #ff6600;
        }
        nav ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }
        .hero {
            text-align: center;
            padding: 80px 20px;
            background: linear-gradient(to right, #ff6600, #ff9933);
            color: #fff;
        }
        .section {
            padding: 50px 20px;
            text-align: center;
            background: #fff;
            margin: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        button {
            background: #ff6600;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: 0.3s;
        }
        button:hover {
            background: #e65c00;
        }
        input {
            padding: 10px;
            width: 100%;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* 🔹 SLIDER STYLES */
        .slider-container {
            position: relative;
            max-width: 100%;
            overflow: hidden;
        }
        .slides {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }
        .slide {
            min-width: 100%;
            transition: 0.5s;
        }
        .slide img {
            width: 100%;
            height: 400px;
            object-fit: cover;
        }
        .prev, .next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            font-size: 20px;
        }
        .prev {
            left: 10px;
        }
        .next {
            right: 10px;
        }
        .dots {
            text-align: center;
            margin-top: 10px;
        }
        .dot {
            height: 12px;
            width: 12px;
            margin: 5px;
            background: #bbb;
            display: inline-block;
            border-radius: 50%;
            cursor: pointer;
        }
        .active {
            background: #ff6600;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">P SMART PARKING</div>
        <nav>
            <ul>
                <li><a href="parking slot.php">Parking Slot</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="admin_login.php">Admin</a></li>
            </ul>
        </nav>
    </header>

    <section class="hero">
        <h1>Modern Smart Parking Solutions</h1>
        <p>Find and book your parking slot effortlessly with our intelligent parking system.</p>
    </section>

    <!-- 🔹 IMAGE SLIDER START -->
    <div class="slider-container">
        <div class="slides">
            <div class="slide"><img src="img/images.jpeg" alt="Parking Area"></div>
            <div class="slide"><img src="img/istockphoto-480652712-612x612.jpg" alt="Smart Parking"></div>
            <div class="slide"><img src="img/Parking-101-Creating-the-Perfect-Car-Park.jpg" alt="Easy Booking"></div>
        </div>
        <button class="prev" onclick="moveSlide(-1)">&#10094;</button>
        <button class="next" onclick="moveSlide(1)">&#10095;</button>
    </div>
    <div class="dots">
        <span class="dot" onclick="currentSlide(0)"></span>
        <span class="dot" onclick="currentSlide(1)"></span>
        <span class="dot" onclick="currentSlide(2)"></span>
    </div>
    <!-- 🔹 IMAGE SLIDER END -->

    <section id="parking" class="section">
        <h2>Parking Slots</h2>
        <p>Real-time availability of parking slots in your area.</p>
        <button onclick="location.href='login.php'">Check Availability</button>
    </section>

    <script>
        let slideIndex = 0;
        let slides = document.querySelectorAll(".slide");
        let dots = document.querySelectorAll(".dot");

        function moveSlide(n) {
            slideIndex += n;
            if (slideIndex >= slides.length) slideIndex = 0;
            if (slideIndex < 0) slideIndex = slides.length - 1;
            updateSlider();
        }

        function currentSlide(n) {
            slideIndex = n;
            updateSlider();
        }

        function updateSlider() {
            document.querySelector(".slides").style.transform = `translateX(-${slideIndex * 100}%)`;
            dots.forEach(dot => dot.classList.remove("active"));
            dots[slideIndex].classList.add("active");
        }

        function autoSlide() {
            moveSlide(1);
            setTimeout(autoSlide, 3000);
        }

        autoSlide();
    </script>

</body>
</html>
