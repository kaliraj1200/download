<?php
session_start();
include 'db_connect.php';

// Debugging: Check what is passed in GET
if (!isset($_GET['slot_id']) || empty($_GET['slot_id']) || !is_numeric($_GET['slot_id'])) {
    die("Error: Parking slot ID is missing or invalid.");
}

$slot_id = intval($_GET['slot_id']);

// Fetch slot details
$query = "SELECT slot_number, location FROM parking_slots WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $slot_id);
$stmt->execute();
$stmt->bind_result($slot_number, $location);
$stmt->fetch();
$stmt->close();

// If no slot details found, show an error
if (empty($slot_number)) {
    die("Error: Invalid Parking Slot.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Booking</title>
    <link rel="stylesheet" href="styles.css">
    <script>
        function calculateTotal() {
            let days = document.getElementById("days").value;
            let perDayCharge = 200;
            let totalAmount = days * perDayCharge;
            document.getElementById("amount").value = totalAmount;
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Book Your Parking Slot</h2>
        <p><strong>Slot Number:</strong> <?php echo $slot_number; ?></p>
        <p><strong>Location:</strong> <?php echo $location; ?></p>

        <form action="process_booking.php" method="post">
            <input type="hidden" name="slot_id" value="<?php echo $slot_id; ?>">

            <label>Name:</label>
            <input type="text" name="user_name" required>

            <label>Phone Number:</label>
            <input type="text" name="phone" required>

            <label>Aadhaar Number:</label>
            <input type="text" name="aadhaar" required>

            <label>Car Number:</label>
            <input type="text" name="car_number" required>

            <label>License Number:</label>
            <input type="text" name="license_number" required>

            <label>Number of Days:</label>
            <input type="number" id="days" name="days" min="1" required oninput="calculateTotal()">

            <label>Total Amount (₹):</label>
            <input type="text" id="amount" name="amount" readonly>

            <button type="submit" class="btn">Proceed to Pay</button>
        </form>
    </div>
</body>
</html>
