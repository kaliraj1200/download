<?php
session_start();
include 'config.php'; // Include database connection

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle "Unbook All" request
if (isset($_GET['unbook_all'])) {
    $occupied_query = $conn->query("SELECT b.id, b.slot_id FROM bookings b JOIN parking_slots s ON b.slot_id = s.id WHERE s.status = 'occupied'");
    while ($row = $occupied_query->fetch_assoc()) {
        $booking_id = $row['id'];
        $slot_id = $row['slot_id'];
        $conn->query("DELETE FROM bookings WHERE id = $booking_id");
        $conn->query("UPDATE parking_slots SET status='available' WHERE id='$slot_id'");
    }
    header("Location: admin_home.php");
    exit();
}

// Handle individual unbook
if (isset($_GET['unbook'])) {
    $id = intval($_GET['unbook']);
    $slot_query = $conn->query("SELECT slot_id FROM bookings WHERE id = $id");
    if ($slot = $slot_query->fetch_assoc()) {
        $conn->query("DELETE FROM bookings WHERE id = $id");
        $conn->query("UPDATE parking_slots SET status='available' WHERE id='{$slot['slot_id']}'");
    }
    header("Location: admin_home.php");
    exit();
}

// Stats
$total_slots = $conn->query("SELECT COUNT(*) AS total FROM parking_slots")->fetch_assoc()['total'];
$occupied_slots = $conn->query("SELECT COUNT(*) AS occupied FROM parking_slots WHERE status='occupied'")->fetch_assoc()['occupied'];
$available_slots = $total_slots - $occupied_slots;

// Fetch booking details WITH users info & slot info (including location)
$bookings_query = $conn->query("
    SELECT 
        b.*, 
        u.name, 
        u.phone, 
        s.slot_number, 
        s.location, 
        s.status AS slot_status
    FROM 
        bookings b 
    LEFT JOIN 
        users u ON b.user_id = u.id 
    LEFT JOIN 
        parking_slots s ON b.slot_id = s.id 
    ORDER BY b.id DESC
");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="Css/adminhome.css">
    <style>
        .btn { padding: 5px 10px; text-decoration: none; border-radius: 4px; }
        .unbook-all { background: crimson; color: white; margin-bottom: 15px; display: inline-block; }
        .verify { background: green; color: white; }
        .unbook { background: orange; color: white; }
        .paid { color: green; font-weight: bold; }
        .pending { color: red; font-weight: bold; }
        .verified { color: green; font-weight: bold; }
        .add-slot { background: blue; color: white; margin-right: 15px; }
    </style>
</head>

<body>

<header>
    <h2>Admin Dashboard</h2>
    <a href="add_slot.php" class="btn add-slot">+ Add Parking Slot</a>
    <a href="logout.php" class="btn" style="background: gray;">Logout</a>
</header>

<div class="dashboard-container">

    <div class="stats">
        <div class="card total">
            <h3>Total Slots</h3>
            <p><?php echo $total_slots; ?></p>
        </div>
        <div class="card occupied">
            <h3>Occupied Slots</h3>
            <p><?php echo $occupied_slots; ?></p>
        </div>
        <div class="card available">
            <h3>Available Slots</h3>
            <p><?php echo $available_slots; ?></p>
        </div>
    </div>

    <!-- Unbook All Button -->
    <?php if ($occupied_slots > 0): ?>
        <a href="admin_home.php?unbook_all=1" class="btn unbook-all" onclick="return confirm('Unbook all occupied slots?')">Unbook All Occupied Slots</a>
    <?php endif; ?>

    <h3>Recent Bookings</h3>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Phone</th>
                <th>Slot</th>
                <th>Location</th>
                <th>Days</th>
                <th>Amount</th>
                <th>Payment</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $bookings_query->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['name'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($row['phone'] ?? 'N/A'); ?></td>
                    <td><?php echo "Slot " . htmlspecialchars($row['slot_number'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($row['location'] ?? 'N/A'); ?></td>
                    <td><?php echo htmlspecialchars($row['days'] ?? 'N/A'); ?></td>
                    <td>₹<?php echo htmlspecialchars($row['amount'] ?? '0'); ?></td>
                    <td>
                        <?php echo ($row['payment_status'] == 'paid') 
                            ? "<span class='paid'>Paid</span>" 
                            : "<span class='pending'>Pending</span>"; ?>
                    </td>
                    <td>
                        <?php if ($row['payment_status'] == 'pending'): ?>
                            <a href="verify_payment.php?id=<?php echo $row['id']; ?>" class="btn verify">Verify</a>
                        <?php else: ?>
                            <span class="verified">Verified</span>
                        <?php endif; ?>
                        <a href="admin_home.php?unbook=<?php echo $row['id']; ?>" class="btn unbook" onclick="return confirm('Unbook this slot?')">Unbook</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</div>

</body>
</html>
