<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>About Us - Parking Booking System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f9f9f9;
        }
        header {
            background: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-radius: 8px;
        }
        h2 {
            color: #007bff;
        }
        p {
            line-height: 1.6;
        }
        .home-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .home-btn:hover {
            background: #0056b3;
        }
        /* Header Styles */
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #222;
    color: #fff;
    padding: 15px 30px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

/* Logo Styles */
.logo {
    font-size: 24px;
    font-weight: bold;
    letter-spacing: 1px;
    text-transform: uppercase;
}

/* Navigation Styles */
nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
}

nav ul li {
    margin: 0 15px;
}

nav ul li a {
    text-decoration: none;
    color: #fff;
    font-size: 16px;
    padding: 8px 12px;
    transition: 0.3s ease-in-out;
}

nav ul li a:hover {
    background: #f4a261;
    color: #222;
    border-radius: 5px;
}

/* Responsive Design */
@media (max-width: 768px) {
    header {
        flex-direction: column;
        text-align: center;
    }

    nav ul {
        flex-direction: column;
        padding-top: 10px;
    }

    nav ul li {
        margin: 5px 0;
    }
}

    </style>
</head>

<body>

    <header>
        <h1>About Our Parking System</h1>
        <div class="logo">P SMART PARKING</div>
        <nav>
            <ul>
                <li><a href="parking slot.php">Parking Slot</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="admin_login.php">Admin</a></li>
            </ul>
        </nav>
    </header>

    <div class="container">
        <h2>Welcome to Our Smart Parking Booking Platform</h2>
        <p>
            Our system allows users to easily book parking slots online, saving time and avoiding the hassle of finding a space manually.
            We aim to make parking management more efficient by providing real-time slot availability, secure payments, and instant booking confirmations.
        </p>
        <p>
            Key features of our system include:
            <ul>
                <li>Easy online booking & management</li>
                <li>Secure UPI payment integration</li>
                <li>Admin panel for real-time slot monitoring</li>
                <li>Automated bill generation and download</li>
            </ul>
        </p>
        <p>
            Our mission is to simplify urban parking and enhance user convenience.
        </p>

        <a href="home.php" class="home-btn">Back to Home</a>
    </div>

</body>

</html>
