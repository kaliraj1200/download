<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit();
}

if (isset($_GET['id'])) {
    $booking_id = intval($_GET['id']);

    // Get slot ID and location before deleting
    $query = "SELECT slot_id FROM bookings WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();
    $stmt->bind_result($slot_id);
    $stmt->fetch();
    $stmt->close();

    if ($slot_id) {
        // Delete booking
        $delete_query = "DELETE FROM bookings WHERE id = ?";
        $stmt = $conn->prepare($delete_query);
        $stmt->bind_param("i", $booking_id);
        
        if ($stmt->execute()) {
            // Mark slot as available
            $conn->query("UPDATE parking_slots SET status='available' WHERE id='$slot_id'");
            header("Location: admin_bookings.php");
            exit();
        } else {
            echo "Failed to delete booking: " . $conn->error;
        }
    } else {
        echo "Error: Booking not found.";
    }
}
?>
