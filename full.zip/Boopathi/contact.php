<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Contact Us - Parking Booking System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
        }
        header {
            background: #28a745;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #28a745;
        }
        p {
            line-height: 1.6;
        }
        form input, form textarea {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            resize: vertical;
        }
        form button {
            margin-top: 15px;
            padding: 10px 20px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        form button:hover {
            background: #218838;
        }
        .back-home {
            display: inline-block;
            margin-top: 20px;
            padding: 8px 16px;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-home:hover {
            background: #218838;
        }
        /* Header Styles */
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #222;
    color: #fff;
    padding: 15px 30px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

/* Logo Styles */
.logo {
    font-size: 24px;
    font-weight: bold;
    letter-spacing: 1px;
    text-transform: uppercase;
}

/* Navigation Styles */
nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
}

nav ul li {
    margin: 0 15px;
}

nav ul li a {
    text-decoration: none;
    color: #fff;
    font-size: 16px;
    padding: 8px 12px;
    transition: 0.3s ease-in-out;
}

nav ul li a:hover {
    background: #f4a261;
    color: #222;
    border-radius: 5px;
}

/* Responsive Design */
@media (max-width: 768px) {
    header {
        flex-direction: column;
        text-align: center;
    }

    nav ul {
        flex-direction: column;
        padding-top: 10px;
    }

    nav ul li {
        margin: 5px 0;
    }
}

    </style>
</head>

<body>

    <header>
        <h1>Contact Us</h1>
        <div class="logo">P SMART PARKING</div>
        <nav>
            <ul>
                <li><a href="parking slot.php">Parking Slot</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="admin_login.php">Admin</a></li>
            </ul>
        </nav>
    </header>

    <div class="container">
        <h2>Get in Touch</h2>
        <p>If you have any questions, feedback, or need support, feel free to contact us using the form below.</p>

        <form action="send_contact.php" method="POST">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
            <button type="submit">Send Message</button>
        </form>

        <a href="home.php" class="back-home">Back to Home</a>
    </div>

</body>

</html>
