<?php
session_start();
include 'db_connect.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    if (!empty($email) && !empty($password)) {
        $query = "SELECT * FROM users WHERE email = ?";
        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION["user"] = $user['email'];
                header("Location: parking slot.php"); // Redirect to parking slots
                exit();
            } else {
                $error = "Invalid email or password!";
            }
        } else {
            $error = "Database error. Please try again later.";
        }
    } else {
        $error = "All fields are required!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <link rel="stylesheet" href="Css/user.css">
    <style>
        /* General Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        /* Background Image */
        body {
            background: url('img/360_F_134620962_YuGh3kkaa7VtFNSJszadQjmCHF7RWENu.jpg') no-repeat center center/cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        /* Header Styles */
        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: rgba(0, 0, 0, 0.9);
            color: #fff;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }

        /* Logo Styles */
        .logo {
            font-size: 24px;
            font-weight: bold;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        /* Navigation Styles */
        nav ul {
            list-style: none;
            display: flex;
        }

        nav ul li {
            margin: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 16px;
            padding: 8px 12px;
            transition: 0.3s;
        }

        nav ul li a:hover {
            background: #f4a261;
            color: #222;
            border-radius: 5px;
        }

        /* Login Form Container */
        .login-container {
            background: rgba(0, 0, 0, 0.75);
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            color: #fff;
            width: 350px;
            margin-top: 80px; /* To prevent overlap with fixed header */
        }

        .login-container h2 {
            margin-bottom: 15px;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .login-container button {
            width: 100%;
            padding: 12px;
            background: #f4a261;
            color: #222;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: 0.3s;
        }

        .login-container button:hover {
            background: #e76f51;
        }

        /* Register Button */
        .login-container p button {
            background: transparent;
            color: #f4a261;
            border: none;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
            font-weight: bold;
        }

        .login-container p button:hover {
            text-decoration: underline;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
            }

            nav ul {
                flex-direction: column;
                padding-top: 10px;
            }

            nav ul li {
                margin: 5px 0;
            }

            .login-container {
                width: 90%;
            }
        }
    </style>
</head>
<body>

<header>
    <div class="logo">P SMART PARKING</div>
    <nav>
        <ul>
            <li><a href="parking_slot.php">Parking Slot</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="admin_login.php">Admin</a></li>
        </ul>
    </nav>
</header>

<!-- Login Form -->
<div class="login-container">
    <h2>Login</h2>
    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
    <form action="" method="POST">
        <label for="email">Email:</label>
        <input type="email" name="email" required>

        <label for="password">Password:</label>
        <input type="password" name="password" required>

        <button type="submit">Login</button>
    </form>
    <p>New user? <button onclick="location.href='register.php'">Register</button></p>
</div>

</body>
</html>
