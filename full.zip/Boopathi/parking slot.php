<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit();
}

include 'db_connect.php';

// Fetch all parking slots grouped by location
$query = "SELECT * FROM parking_slots ORDER BY location, slot_number";
$result = $conn->query($query);

// Categorize slots by location + count
$parking_slots = [];
$total_count = 0;
$occupied_count = 0;
$available_count = 0;

while ($row = $result->fetch_assoc()) {
    $parking_slots[$row['location']][] = $row;
    $total_count++;
    if ($row['status'] == 'occupied') {
        $occupied_count++;
    } else {
        $available_count++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking Slots - Sivakasi</title>
    <link rel="stylesheet" href="Css/parking.css">
    <style>
        header {
            background: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
            position: relative;
        }
        header a {
            position: absolute;
            right: 20px;
            top: 20px;
            color: #fff;
            text-decoration: none;
            padding: 8px 12px;
            background: #e74c3c;
            border-radius: 5px;
        }
        .slot-stats {
            font-size: 16px;
            margin-top: 5px;
            color: #f1f1f1;
        }
        .parking-container {
            padding: 20px;
        }
        .slot-container {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 30px;
        }
        .slot {
            border: 1px solid #ddd;
            padding: 10px;
            width: 150px;
            text-align: center;
            border-radius: 5px;
        }
        .slot.available {
            background: #d4edda;
            border-color:rgb(0, 204, 48);
        }
        .slot.occupied {
            background: #f8d7da;
            border-color: #dc3545;
        }
        .book-btn {
            background: #007bff;
            color: white;
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <header>
        <h2>Parking Slots - Sivakasi</h2>
        <div class="slot-stats">
            Total Slots: <?php echo $total_count; ?> | Occupied: <?php echo $occupied_count; ?> | Available: <?php echo $available_count; ?>
        </div>
        <a href="logout.php">Logout</a>
    </header>

    <div class="parking-container">
        <?php foreach ($parking_slots as $location => $slots): ?>
            <h3><?php echo $location; ?> Parking</h3>
            <div class="slot-container">
                <?php foreach ($slots as $slot): ?>
                    <div class="slot <?php echo $slot['status'] == 'occupied' ? 'occupied' : 'available'; ?>">
                        <p>Slot <?php echo $slot['slot_number']; ?></p>
                        <p>Status: <?php echo ucfirst($slot['status']); ?></p>
                        <?php if ($slot['status'] == 'available'): ?>
                            <a href="booking_details.php?slot_id=<?php echo $slot['id']; ?>">
                                <button class="book-btn">Book Now</button>
                            </a>
                        <?php else: ?>
                            <button disabled>Booked</button>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
