<?php
session_start();
if (!isset($_SESSION["admin"])) {
    header("Location: admin_login.php");
    exit();
}

include 'db_connect.php';

$query = "SELECT b.id, b.user_name, b.phone, b.aadhaar, b.car_number, b.license_number, 
                 b.days, b.amount, b.payment_status, b.slot_id, p.location, p.slot_number
          FROM bookings b
          JOIN parking_slots p ON b.slot_id = p.id
          ORDER BY b.id DESC";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Booking Details</title>
    <link rel="stylesheet" href="admin_styles.css">
</head>
<body>
    <header>
        <h2>Admin Panel - Booking Details</h2>
        <a href="admin_logout.php" class="logout-btn">Logout</a>
    </header>
    
    <div class="container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User Name</th>
                    <th>Phone</th>
                    <th>Aadhaar</th>
                    <th>Car Number</th>
                    <th>License</th>
                    <th>Days</th>
                    <th>Amount (₹)</th>
                    <th>Payment Status</th>
                    <th>Parking Slot</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['user_name']; ?></td>
                        <td><?php echo $row['phone']; ?></td>
                        <td><?php echo $row['aadhaar']; ?></td>
                        <td><?php echo $row['car_number']; ?></td>
                        <td><?php echo $row['license_number']; ?></td>
                        <td><?php echo $row['days']; ?></td>
                        <td><?php echo $row['amount']; ?></td>
                        <td><?php echo ucfirst($row['payment_status']); ?></td>
                        <td><?php echo $row['location'] . ' - Slot ' . $row['slot_number']; ?></td>
                        <td>
                            <a href="delete_booking.php?id=<?php echo $row['id']; ?>" class="delete-btn">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
